#ifndef RID_H
#define RID_H

// structure declaration for a record identifier

typedef struct RID{
    int  pageNo;
    int	 slotNo;
};

#endif

